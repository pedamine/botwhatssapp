const chalk = require('chalk')
const fs = require('fs')

//SELEBIHNYA JIKA MAU SETTING ADA DI FOLDER JS 

//api ibeng
global.apiibeng = 'APIKEY' // letakan apikey kalian daftar dlu ya
// •> https://api.ibeng.tech
//lalu klian daftar jika sudah daftar di dashboard ada tulisan apikey kalian salin aja Paste di 'APIKEY'





global.owner = ['6282295258707'] 
global.ownernomer = "6282295258707"
global.socialmedia = "IG: Pedamine"
global.yutub = "YT: gak ada"
global.lokasi = "Indonesia, Jawabarat, karawang"
global.sakuraurl = 'https://lenttobs.xyz'
global.packgename = "by" 
global.author = "Muwahid" 
global.title = 'Pedamine'
global.body = 'Subscribe '
global.welcome = false //false mati true nyala
global.left = false //false mati true nyala
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Telah di update'${__filename}'`))
	delete require.cache[file]
	require(file)
})